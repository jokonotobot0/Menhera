const { exec } = require('child_process');
const systeminformation = require('systeminformation');
const os = require('os');
const chalk = require('chalk');
const fs = require('fs')
const moment = require('moment-timezone');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');
const path = require('path');
const { Sticker } = require('wa-sticker-formatter')
const yts = require("yt-search");
const axios = require("axios");


moment.locale('id');

// disini fungsi memanggil penanganan pesan di index js 
// gua memakai module.exports.handleincomingMessage 
// dia akan memangil di index.js
module.exports.handleIncomingMessage = async (nvdia, msg) => {
    const sender = msg.key.remoteJid;
    const timezone = 'Asia/Jakarta';
    const jam = moment().tz(timezone).format('dddd DD-MM-YYYY HH:mm:ss');
    const contactName = msg.pushName || 'Unknown';
    console.log(`💬 ${contactName} : ${msg.message?.conversation || 'No message'}\n`);
    const messageType = msg.message.conversation
        ? 'conversation'
        : Object.keys(msg.message)[0];

    let messageContent;
    
    if (messageType === 'conversation') {
        messageContent = msg.message.conversation;
    } else if (messageType === 'extendedTextMessage') {
        messageContent = msg.message.extendedTextMessage.text;
    } else if (messageType === 'imageMessage') {
        messageContent = msg.message.imageMessage.caption || '';
    } else if (messageType === 'videoMessage') {
        messageContent = msg.message.videoMessage.caption || '';
    } else if (messageType === 'documentMessage') {
        messageContent = msg.message.documentMessage.caption || '';
    } else if (messageType === 'stickerMessage') {
        messageContent = '[Sticker]';
    } else if (messageType === 'contactMessage') {
        messageContent = '[Contact]';
    } else {
        messageContent = '';
    }

    // Console message
    console.log(
        chalk.green(`[${new Date().toLocaleTimeString()}]`) + 
        chalk.blue(` Pesan diterima dari `) + chalk.bold(sender) + 
        chalk.yellow(`: "${messageContent}"`) + 
        chalk.magenta(` (Type: ${messageType})`) 
    );

    // Multi-prefix
    const prefixes = ['!', '.', '']; 
    const prefixUsed = prefixes.find((prefix) => messageContent.startsWith(prefix)) || '';
    const command = prefixUsed
        ? messageContent.slice(prefixUsed.length).split(' ')[0].toLowerCase()
        : messageContent.split(' ')[0].toLowerCase();
    const args = prefixUsed
        ? messageContent.slice(prefixUsed.length).split(' ').slice(1)
        : messageContent.split(' ').slice(1);
        

    
  try {
    switch (command) {
      case 'stiker':
case 'sticker':
case 's':
case 'tikel':
    // Cek apakah pesan memiliki media (gambar, video, atau GIF)
    if (
        msg.message?.imageMessage || 
        msg.message?.videoMessage || 
        msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage ||
        msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.videoMessage
    ) {
        try {
            // Tentukan apakah itu gambar atau video
            const isImage = msg.message?.imageMessage || 
                            msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage;
            const isVideo = msg.message?.videoMessage || 
                            msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.videoMessage;

            // Download media
            const buffer = await downloadMediaMessage(
                isImage ? (msg.message.imageMessage ? msg : await msg.getQuotedMessage()) :
                (msg.message.videoMessage ? msg : await msg.getQuotedMessage()), 
                'buffer',
                {}
            );

            // Buat sticker menggunakan wa-sticker-formatter
            const sticker = new Sticker(buffer, {
                pack: 'Sticker', // Nama pack sticker
                author: `Dibuat pada-${jam}`, // Nama author
                type: 'full', // Full sticker
                categories: ['🤩', '🎉'], // Kategori sticker
                quality: 50, // Kualitas sticker
                id: `sticker_${Date.now()}`, // Unique ID
                background: 'transparent' // Background transparan
            });

            // Jika ini adalah video, set config tambahan
            if (isVideo) {
                sticker.setFps(10); // Set FPS untuk video/GIF
                sticker.setLoop(true); // Set loop untuk video/GIF
            }

            // Convert ke buffer
            const stickerBuffer = await sticker.toBuffer();

            // Kirim sticker
            await nvdia.sendMessage(sender, {
                sticker: stickerBuffer,
                contextInfo: {
                    externalAdReply: {
                        title: 'Sticker',
                        body: `${jam}`,
                        mediaType: 1
                    }
                }
            });

        } catch (mediaError) {
            console.error('Sticker creation error:', mediaError);
            await nvdia.sendMessage(sender, { 
                text: 'Gagal membuat stiker, pastikan media valid dan tidak terlalu besar.' 
            });
        }
    } else {
        await nvdia.sendMessage(sender, { 
            text: 'Kirim gambar/video dengan caption .stiker atau reply gambar/video dengan .stiker' 
        });
    }
    break;
    
        case 'halo':
        await reply(nvdia, msg, 'Mohon reply pesan dengan gambar atau ketik teks untuk menghasilkan pesan.');
      
            break;
          case 'menu':
          let menuk = `Halo! Aku bot *NVDIA*
• info < info bot >
• ping < check ping >
• halo < test bot >`
           nvdia.sendMessage(sender, { text: menuk})
            break;

        case 'info':
            await reply(nvdia, msg, 'Ini adalah bot WhatsApp sederhana dengan multi-prefix!');
            break;

        case 'ping':
            const startTime = Date.now();
            await reply(nvdia, msg, 'Memeriksa status...');
            const uptime = os.uptime();
            const systemInfo = await systeminformation.getStaticData();
            const cpuInfo = systemInfo.cpu;
            const memoryInfo = systemInfo.mem;

            const pingMessage = `Pong! 🏓
Waktu ping: ${Date.now() - startTime}ms
Uptime: ${formatUptime(uptime)}
OS: ${os.platform()} ${os.release()}
CPU: ${cpuInfo.manufacturer} ${cpuInfo.brand} - ${cpuInfo.speed}GHz
            `;
            await reply(nvdia, msg, pingMessage);
            break;
            
                  // Command untuk fitur neofetch;
        case 'neofetch':
    exec('neofetch --stdout', (error, stdout, stderr) => {
        if (error) {
            console.error(`exec error: ${error}`);
            reply(nvdia, msg, `Error executing neofetch: ${error.message}`);
            return;
        }
        if (stderr) {
            console.error(`stderr: ${stderr}`);
            reply(nvdia, msg, `Error: ${stderr}`);
            return;
        }
        reply(nvdia, msg, `${stdout}`);
    });
    break;
            
case 'brat': {
    if (!args.length) {
        await reply(nvdia, msg, `Penggunaan: ${prefixUsed + command} <teks>`);
        return;
    }

    try {
        const { createCanvas, registerFont } = require('canvas');
        const Jimp = require('jimp');
        
        registerFont('./lib/arialnarrow.ttf', { family: 'ArialNarrow' });

        const canvas = createCanvas(512, 512);
        const ctx = canvas.getContext('2d');

        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        const findOptimalFontSize = (text, maxWidth, maxHeight) => {
            let fontSize = 100;
            ctx.font = `bold ${fontSize}px ArialNarrow`;
            const words = text.split(' ');
            let lines = [];

            while (fontSize > 0) {
                lines = [];
                let currentLine = [];
                let currentWidth = 0;
                ctx.font = `bold ${fontSize}px ArialNarrow`;

                for (const word of words) {
                    const wordWidth = ctx.measureText(word + ' ').width;
                    if (currentWidth + wordWidth <= maxWidth) {
                        currentLine.push(word);
                        currentWidth += wordWidth;
                    } else {
                        if (currentLine.length > 0) {
                            lines.push(currentLine);
                        }
                        currentLine = [word];
                        currentWidth = wordWidth;
                    }
                }
                if (currentLine.length > 0) {
                    lines.push(currentLine);
                }

                const totalHeight = lines.length * (fontSize + 10);
                if (totalHeight <= maxHeight) {
                    break;
                }
                fontSize -= 2;
            }
            return { fontSize, lines };
        };

        const padding = 40;
        const maxWidth = canvas.width - (padding * 2);
        const maxHeight = canvas.height - (padding * 2);
        const text = args.join(' ');
        const { fontSize, lines } = findOptimalFontSize(text, maxWidth, maxHeight);

        ctx.fillStyle = '#000000';
        ctx.font = `bold ${fontSize}px ArialNarrow`;
        
        const lineHeight = fontSize + 10;
        const totalHeight = lines.length * lineHeight;
        const startY = (canvas.height - totalHeight) / 2 + fontSize / 2;

        lines.forEach((line, i) => {
            if (line.length === 1) {
                ctx.textAlign = 'left';
                ctx.fillText(line.join(' '), padding, startY + (i * lineHeight));
            } else {
                const totalSpacing = maxWidth - line.reduce((acc, word) => acc + ctx.measureText(word).width, 0);
                const spaceBetween = line.length > 1 ? totalSpacing / (line.length - 1) : 0;
                
                let currentX = padding;
                line.forEach((word, j) => {
                    ctx.fillText(word, currentX, startY + (i * lineHeight));
                    currentX += ctx.measureText(word).width + spaceBetween;
                });
            }
        });
        
        const buffer = canvas.toBuffer();
        let image = await Jimp.read(buffer);
        image.blur(2);
        
        // Convert Jimp image to buffer
        const imageBuffer = await image.getBufferAsync(Jimp.MIME_PNG);
        
        // Create sticker using wa-sticker-formatter
        const sticker = new Sticker(imageBuffer, {
            pack: 'Sticker', // Nama pack sticker
            author: `Dibuat pada-${jam}`, // Nama author
            type: 'full', // Full sticker
            categories: ['🤩', '🎉'], // Kategori sticker
            quality: 50 // Kualitas sticker
        });
        
        // Convert to buffer
        const stickerBuffer = await sticker.toBuffer();
        
        // Kirim sticker
        await nvdia.sendMessage(sender, {
                sticker: stickerBuffer,
                contextInfo: {
                    externalAdReply: {
                        title: 'Brat sticker',
                        body: `${jam}`,
                        mediaType: 1
                    }
                }
            });

    } catch (e) {
        console.error('Error in brat command:', e);
        await reply(nvdia, msg, `Terjadi kesalahan saat membuat stiker: ${e.message}`);
    }
}
break;

case 'play': {
    if (!args.length) {
        await reply(nvdia, msg, `Masukan judul/link!\ncontoh:\n\n${prefixUsed + command} sephia\n${prefixUsed + command} https://youtube.com/watch?v=example`);
        return;
    }

    try {
        const searchQuery = args.join(' ');
        const ytRegex = /^(https?:\/\/)?(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)[\w\-_]+/;
        let videoUrl, title, thumbnail, convert;
        
        if (ytRegex.test(searchQuery)) {
            // Jika input adalah URL YouTube
            videoUrl = searchQuery.trim();
            const videoId = videoUrl.match(/[\w\-_]+$/)[0];
            convert = await yts({ videoId, hl: 'id', gl: 'ID' });
        } else {
            // Jika input adalah kata kunci pencarian
            const search = await yts(searchQuery);
            if (!search || !search.videos.length) {
                await reply(nvdia, msg, 'Audio tidak ditemukan. Silakan coba kata kunci lain.');
                return;
            }
            convert = search.videos[0];
            videoUrl = convert.url;
        }

        title = convert.title;
        thumbnail = convert.thumbnail;

        // Kirim pesan loading
        const loadingMsg = await reply(nvdia, msg, `⌛ Sedang memproses audio...\n\n*Judul:* ${title}\n*Channel:* ${convert.author.name}`);

        // Encode URL untuk API request
        const encodedUrl = encodeURIComponent(videoUrl);
        
        // Get audio data from cifumo API with required parameters
        const res = await axios.get(`https://rest.cifumo.xyz/download/youtube?url=${encodedUrl}&type=audio&quality=144`, {
            responseType: 'json'
        });

        // Check if response contains the download URL
        if (!res.data || !res.data.result || !res.data.result.downloadUrl) {
            await reply(nvdia, msg, 'Gagal mendapatkan audio. Pastikan URL benar dan video tidak terlalu panjang.');
            return;
        }

        const audioUrl = res.data.result.downloadUrl;

        // Kirim audio dengan metadata
        await nvdia.sendMessage(msg.key.remoteJid, {
            audio: { url: audioUrl },
            mimetype: 'audio/mpeg',
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: convert.title,
                    mediaType: 1,
                    previewType: 1,
                    body: convert.author ? convert.author.name : 'YouTube Audio',
                    thumbnailUrl: convert.thumbnail,
                    renderLargerThumbnail: true,
                    mediaUrl: convert.url,
                    sourceUrl: convert.url
                }
            }
        }, { quoted: msg });

    } catch (e) {
        console.error("Error pada fitur play:", e);
        let errorMsg = 'Terjadi kesalahan saat memproses video.';
        
        if (e.response) {
            // Handle specific API errors
            const status = e.response.status;
            if (status === 404) {
                errorMsg = 'Video tidak ditemukan.';
            } else if (status === 400) {
                errorMsg = 'Parameter tidak valid. Pastikan URL YouTube benar.';
            } else if (status === 403) {
                errorMsg = 'Akses ke API dibatasi.';
            } else {
                errorMsg = `Terjadi kesalahan pada API: ${status}`;
            }
        }
        
        await reply(nvdia, msg, errorMsg);
    }
}
break;
}


    
  } catch (error) {
        console.error('Error in message handler:', error);
        
  // Reply error jika terjadi masalah
        await reply(nvdia, msg, `Maaf, terjadi kesalahan: ${error.message}`);
    }
};



async function reply(nvdia, msg, replyText) {
    if (msg.key && msg.key.remoteJid) {
        await nvdia.sendMessage(msg.key.remoteJid, {
            text: replyText,
            quoted: msg, 
        });
    }
}

function formatUptime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${hours} jam, ${minutes} menit, ${remainingSeconds} detik`;
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})
